# Day 10: Linear Regression Advanced

Run with:
```bash
python day10.py
```
