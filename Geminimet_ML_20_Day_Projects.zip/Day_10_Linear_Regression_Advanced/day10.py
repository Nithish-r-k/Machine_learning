# Day 10: Linear Regression Advanced

print('This is Day 10 - Linear_Regression_Advanced')
