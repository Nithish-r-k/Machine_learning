# Day 12: KNN Classification

Run with:
```bash
python day12.py
```
