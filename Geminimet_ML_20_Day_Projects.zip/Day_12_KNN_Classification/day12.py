# Day 12: KNN Classification

print('This is Day 12 - KNN_Classification')
