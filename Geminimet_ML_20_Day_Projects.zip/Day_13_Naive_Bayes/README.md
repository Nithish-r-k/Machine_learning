# Day 13: Naive Bayes

Run with:
```bash
python day13.py
```
