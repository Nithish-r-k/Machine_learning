# Day 13: Naive Bayes

print('This is Day 13 - Naive_Bayes')
