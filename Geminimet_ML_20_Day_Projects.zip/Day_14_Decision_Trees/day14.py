# Day 14: Decision Trees

print('This is Day 14 - Decision_Trees')
