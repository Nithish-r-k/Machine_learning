# Day 17: Unsupervised Clustering

print('This is Day 17 - Unsupervised_Clustering')
