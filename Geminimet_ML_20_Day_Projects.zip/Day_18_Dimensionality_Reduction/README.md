# Day 18: Dimensionality Reduction

Run with:
```bash
python day18.py
```
