# Day 18: Dimensionality Reduction

print('This is Day 18 - Dimensionality_Reduction')
