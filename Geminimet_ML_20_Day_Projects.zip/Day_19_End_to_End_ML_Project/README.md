# Day 19: End to End ML Project

Run with:
```bash
python day19.py
```
