# Day 20: ML Capstone Project

Run with:
```bash
python day20.py
```
