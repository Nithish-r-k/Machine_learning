# Day 20: ML Capstone Project

print('This is Day 20 - ML_Capstone_Project')
