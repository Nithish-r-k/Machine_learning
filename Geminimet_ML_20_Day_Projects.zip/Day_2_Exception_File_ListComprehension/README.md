# Day 2: Exception File ListComprehension

Run with:
```bash
python day2.py
```
