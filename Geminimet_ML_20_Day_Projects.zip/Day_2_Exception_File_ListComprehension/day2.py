# Day 2: Exception File ListComprehension

print('This is Day 2 - Exception_File_ListComprehension')
