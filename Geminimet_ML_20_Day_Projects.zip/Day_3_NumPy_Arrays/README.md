# Day 3: NumPy Arrays

Run with:
```bash
python day3.py
```
