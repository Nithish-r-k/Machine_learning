# Day 3: NumPy Arrays

print('This is Day 3 - NumPy_Arrays')
