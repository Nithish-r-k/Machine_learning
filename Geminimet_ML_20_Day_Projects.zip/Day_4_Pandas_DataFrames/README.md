# Day 4: Pandas DataFrames

Run with:
```bash
python day4.py
```
