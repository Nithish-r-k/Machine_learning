# Day 4: Pandas DataFrames

print('This is Day 4 - Pandas_DataFrames')
