# Day 5: Data Cleaning

Run with:
```bash
python day5.py
```
