# Day 5: Data Cleaning

print('This is Day 5 - Data_Cleaning')
