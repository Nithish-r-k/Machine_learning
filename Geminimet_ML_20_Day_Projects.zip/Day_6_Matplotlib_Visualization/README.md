# Day 6: Matplotlib Visualization

Run with:
```bash
python day6.py
```
