# Day 6: Matplotlib Visualization

print('This is Day 6 - Matplotlib_Visualization')
