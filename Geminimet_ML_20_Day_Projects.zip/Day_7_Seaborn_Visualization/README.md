# Day 7: Seaborn Visualization

Run with:
```bash
python day7.py
```
