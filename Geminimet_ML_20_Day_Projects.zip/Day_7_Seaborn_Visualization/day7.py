# Day 7: Seaborn Visualization

print('This is Day 7 - Seaborn_Visualization')
