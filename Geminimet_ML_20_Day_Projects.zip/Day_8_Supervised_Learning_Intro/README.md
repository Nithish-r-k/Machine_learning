# Day 8: Supervised Learning Intro

Run with:
```bash
python day8.py
```
