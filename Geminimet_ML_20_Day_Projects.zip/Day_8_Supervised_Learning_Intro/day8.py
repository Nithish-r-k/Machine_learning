# Day 8: Supervised Learning Intro

print('This is Day 8 - Supervised_Learning_Intro')
