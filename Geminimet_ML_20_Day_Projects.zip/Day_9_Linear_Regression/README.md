# Day 9: Linear Regression

Run with:
```bash
python day9.py
```
