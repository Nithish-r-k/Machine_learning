# Day 9: Linear Regression

print('This is Day 9 - Linear_Regression')
